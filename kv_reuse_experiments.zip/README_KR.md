# Qwen3 반복 재사용 및 캐시 압박 E2E 실험

이 개선본은 `exp/mapper-optim`의 `a5f8c97`에 직접 적용하는 패치입니다. 기존 서빙 엔진, 매퍼 체크포인트, Slurm 스크립트와 기존 프로파일을 사용합니다.

| 위치 | 책임 |
| --- | --- |
| `proposed/validation/config.py` | 프로파일, KV 용량, 반복 횟수와 데이터 경로 |
| `proposed/validation/e2e_inputs.py`, `serving_e2e.py` | 공통 프롬프트 검증과 기존 E2E 실행 |
| `proposed/validation/e2e_workload.py`, `e2e_figures.py` | 공통 집계와 CSV·PDF·PNG 출력 |
| `proposed/validation/reuse_experiment/qasper_cohort.py` | QASPER 원본에서 공동 문서·질문 선별 |
| `proposed/validation/reuse_experiment/request_schedule.py` | 다중 질문 및 캐시 압박용 요청 순서 |
| `proposed/src/cache/prefix.py` | 기존 LRU의 퇴거 계측 |

저장소의 `AGENTS.md`에는 기존 구현 개선을 우선하고, 독립적인 실험 로직에만 책임별 폴더와 파일을 추가한다는 원칙을 담았습니다.

## 1. 한 번만 준비

현재 실행 중인 기존 실험의 결과가 나온 후 저장소 루트에 `kv_reuse_experiments.zip`을 올립니다.

```bash
cd /data/surt321/repos/lab/kv_cache
git status --short
unzip -n kv_reuse_experiments.zip -d proposed/work/kv_reuse_experiments
git apply --check proposed/work/kv_reuse_experiments/kv_reuse_experiments.patch &&
git apply proposed/work/kv_reuse_experiments/kv_reuse_experiments.patch
```

`git apply --check`가 실패하면 해당 출력을 확인합니다. 저장소 상태를 그대로 유지한 채 실패한 파일을 확인할 수 있습니다.

```bash
mkdir -p /data/surt321/kv_mapper_optim_runs/datasets
cp -n proposed/work/kv_reuse_experiments/qasper-test-and-evaluator-v0.3.tgz \
  /data/surt321/kv_mapper_optim_runs/datasets/
```

러너가 SHA-256을 확인하며 Seraph에서는 로컬 파일을 사용합니다. 기존 LongBench 묶음도 매퍼 보정 문서의 중복 확인에 사용합니다.

## 2. 제출

`proposed/validation/config.py`의 다음 항목을 확인합니다. 설정의 기존 값을 기록해 두면 이전 실험으로 돌아갈 때 복원할 수 있습니다.

```python
E2E_PAIR = "0.6b-8b"
E2E_QA_JOB = "223131"
E2E_QA_REPORT = None
E2E_PROFILE = "reuse_pilot"
```

저장소 루트에서 각 프로파일에 같은 명령을 사용합니다.

```bash
sbatch run/seraph/qwen3_serving_e2e.sh
```

| 프로파일 | 조건 | 확인 목표 |
| --- | --- | --- |
| `reuse_pilot` | 4문서 × 4질문, 1 GiB, source prefill당 질문 1/2/4개 | 3가지 경로와 출력 생성 확인. 시나리오별 target QA 16건, cross-model 대상 8건 |
| `reuse_amortization` | 12문서 × 4질문, 1 GiB, source prefill당 질문 1/2/4개 | source prefill 비용을 나눠 쓸 때 E2E 차이 확인 |
| `reuse_pressure` | 동일한 12문서 × 4질문, source prefill당 질문 4개, 512/1024/2048 MiB | 문서 4개씩 KV를 적재하고 질문을 교차 요청하며 용량별 hit와 LRU 퇴거 차이 확인 |

job ID를 받은 후 SSH를 닫아도 됩니다. pilot 결과의 `status`와 `figures.status`가 `complete`이면 `E2E_PROFILE`만 `reuse_amortization`으로 바꿔 제출합니다. 본실험이 끝나면 `reuse_pressure`로 바꿔 같은 명령을 다시 실행합니다. 대기 중인 Slurm 작업이 시작할 때 config를 읽으므로 앞선 작업이 끝난 후 값을 바꿉니다.

## 3. 결과 해석

출력은 `results/semcache/e2e_<JOB_ID>/`에 저장합니다. 공유할 파일은 `report-top-system-e2e.json`입니다. `figures/`에는 `reuse_e2e`와 `reuse_cache`의 PDF·PNG, `reuse_metrics.csv`가 생성됩니다.

- 세 방법은 각 조건에서 동일한 producer와 target 요청을 받습니다. 반복 횟수를 바꾸면 target 질문 순서는 유지되고 producer 수가 달라집니다. 조건별로 Proposed와 두 baseline 사이의 차이를 비교합니다.
- `Elapsed time per target QA`는 모든 producer를 포함한 trace 시간을 target 질문 수로 나눈 값입니다. TTFT는 target 요청의 첫 토큰까지의 시간입니다. 두 지표를 함께 보면 기존 캐시 조회부터 새 모델의 첫 토큰까지 걸리는 시간과 전체 작업 비용을 구분할 수 있습니다. Proposed는 hit마다 기존 source KV를 매핑합니다.
- 캐시 용량은 KV pool의 상한입니다. `Peak resident KV` 및 `Median KV budget used` 값으로 실제 적재량을 보고 GPU 전체 peak allocation과 따로 해석합니다. 본실험에서 eligible cross-model hit rate의 분모는 리플레이당 24건입니다. 매퍼 보정 문서와 정규화한 16단어 연속 구간을 공유하는 QASPER 본문을 선별에서 제외합니다.
- QA 품질은 근거가 본문에 존재하는 원본 질문으로 채점합니다. F1과 EM을 수집하며, paired bootstrap은 문서 단위로 수행합니다. 이 평가 범위는 QASPER의 answerable subset입니다.

패치를 걷어내려면 config의 네 설정을 적용하기 전 값으로 돌린 후 저장소 루트에서 다음을 실행합니다.

```bash
git apply -R --check proposed/work/kv_reuse_experiments/kv_reuse_experiments.patch &&
git apply -R proposed/work/kv_reuse_experiments/kv_reuse_experiments.patch
```

## 데이터 출처

QASPER v0.3 test archive는 Dasigi et al. (2021), *A Dataset of Information-Seeking Questions and Answers Anchored in Research Papers*의 공식 배포본입니다. ZIP에 원본 아카이브를 포함했습니다. [공식 데이터 페이지](https://allenai.org/data/qasper) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
